<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="pinktilesheet" tilewidth="32" tileheight="32" tilecount="72" columns="9">
 <image source="../../../../../../Desktop/images/pinktilesheet.png" width="288" height="256"/>
</tileset>
