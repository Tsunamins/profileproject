particlesJS.load('particles-js', '../style/particles.json', function() {
    console.log('callback - particles.js config loaded');
  });